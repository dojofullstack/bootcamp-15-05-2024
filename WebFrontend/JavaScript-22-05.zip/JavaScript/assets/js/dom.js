

// console.log("ejecutnod bloqueCodigo");
// const inputPin = document.getElementById("pin-csv");
// console.log(inputPin.value);



function obtenerPinCard(){
    console.log("ejecutando funcion obtenerPinCard");
    // const inputPin = document.getElementById("pin-csv");
    // const inputPin = document.getElementsByClassName("pin-csv");

    const inputPin = document.querySelector("#pin-csv");
    // console.log(inputPin);
    console.log(inputPin.value);
    console.log(inputPin.value.length);
    // alert("correcto tiene 3 digitos")
}



obtenerPinCard;