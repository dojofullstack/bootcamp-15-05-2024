



// tipo de dato String
let apellidoCompleto = "pedro sanchze";
let email_secondario = "pedro@gmail.com";
let username_ = "pedro";
let _edad =  '30';
let APIKEY = "1029019201";

// let salidaInfo =  typeof _edad;
// console.log(salidaInfo);
// console.log(APIKEY);

let pinVisaCSV = "401";
let nombre = "henry dojo";

// console.log(pinVisaCSV.length);

// console.log(nombre.concat(" dojo"));

// console.log(nombre.includes("dojo") );

// console.log(nombre.indexOf("henry") );

// console.log(nombre.replace("youtube", "bootcamp").replace("dojo", "bootcamp").replace("henry", "HENRY") );


// console.log(nombre.startsWith("henry") );
// console.log(nombre.endsWith("dojo") );

// console.log(nombre.search("dojo"));



// tipo de dato Bool
const isAdmin = true;
let isUserVip = false;

console.log(isAdmin);
console.log(isUserVip);
console.log( typeof isUserVip );



// tipos de datos Numericos y Flot



// tipos de datos Flotantes
let precio = 90; //numeral entero
let precioEspecial = 50.59;   //numeral flotante o decimal
let datanoNumber = NaN;

// BigInt
let calculoPi = 11892918298129810121121289182981678n;


// console.log(typeof precio);
// console.log(typeof precioEspecial);
// console.log(datanoNumber);
// console.log(typeof datanoNumber);
// console.log(calculoPi);

console.log( parseInt("123"));
console.log(parseFloat("789.53"));
console.log(Number("78.7"));

let precioBlackFridy = 9.932;

let precioParse = precioBlackFridy.toFixed(1);

// document.querySelector("#mostrar-precio").innerHTML = "<b>Precio:</b> " + precioParse ;

document.querySelector("#mostrar-precio").innerHTML = `<b>Precio Especial:</b> ${precioParse}`  ;


// operaciones basicas
let suma = 10 + 5;        // 15
let resta = 10 - 5;       // 5
let multiplicacion = 10 * 5; // 50
let division = 10 / 5;    // 2
let modulo = 10 % 3;      // 1 (resto de la división)
console.log(multiplicacion)






// Objetos y Arrays

// Estrucuta de Datos (condciones, ciclos, funciones)
// Clases y POO

// Tienda Virtual para Wasap & creador de productos
