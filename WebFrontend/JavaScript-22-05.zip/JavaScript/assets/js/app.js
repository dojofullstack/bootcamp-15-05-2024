
console.log("cargando modulo app.js, listo!");


// Variables JS (3 formas para definir variables)
var edad = 20;
let usuario = "carlos";


// constantes
const email = "carlos@gmail.com";
const precio = 32;
const isMiembroVip = true;


edad = 90;
usuario = "henry";
console.log(edad);
console.log(usuario);



// isMiembroVip = false;
// email = "pedro@gmail.com";

console.log(email);
console.log(isMiembroVip);


console.log(versionApp);